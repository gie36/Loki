'use strict';

class Exception {
    static get NotImplemented() {
        return 'NotImplementedError';
    }
}
