# Changelog

Changes for this project will be documented here

## [0.1.1] - 2020-03-12

### Changed

-   UI
-   Lighter payload size; from 22,773 KB to 9,490 KB
-   Builder only outputs exe

### Removed

-   Tasks
